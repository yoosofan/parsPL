					QNotepad - a very simple text editor
		written in PyQT4 by Piotr "Riklaunim" Malinski <riklaunim@gmail.com>
			How it's made on http://www.rkblog.rk.edu.pl/w/p/introduction-pyqt4/ :)

USAGE:
- You need PyQT4
- run "start.py" - "python start.py"


ICON:
Author:Rokey
site: www.rokey.net